// ============================================================
// firebaseConfig.js
// ============================================================
// HOW TO FILL THIS IN:
// 1. Go to https://console.firebase.google.com
// 2. Select your project
// 3. Click the gear icon ⚙️ → "Project Settings"
// 4. Scroll to "Your apps" → click your web app (</>)
// 5. Copy each value from the firebaseConfig object shown
//    and paste it below, replacing the placeholder text.
// ============================================================

export const firebaseConfig = {
  apiKey:            "PASTE_YOUR_API_KEY_HERE",
  authDomain:        "PASTE_YOUR_AUTH_DOMAIN_HERE",
  projectId:         "PASTE_YOUR_PROJECT_ID_HERE",
  storageBucket:     "PASTE_YOUR_STORAGE_BUCKET_HERE",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID_HERE",
  appId:             "PASTE_YOUR_APP_ID_HERE",
};
